#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QKeyEvent>
#include <QRegularExpression>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


protected:
    // 后续键盘事件需重写此函数，此处先预留声明
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    // 步骤2：数字键槽函数
    void onNumberClicked();
    // 步骤2：小数点槽函数
    void onDotClicked();
    // 步骤2：退格槽函数
    void onBackspaceClicked();
    // 步骤3：运算符槽函数（后续实现）
    void onOperatorClicked();
    // 步骤3：等号槽函数（后续实现）
    void onEqualClicked();
    // 步骤3：清除槽函数（后续实现）
    void onClearClicked();
    // 步骤4：百分号槽函数（后续实现）
    void onPercentClicked();

private:
    Ui::MainWindow *ui;
    // 步骤2：核心状态变量
    double firstNum;       // 第一个操作数
    double secondNum;      // 第二个操作数
    QString operatorStr;   // 运算符（+/-/*//）
    bool isFirstInput;     // 是否第一次输入
    bool isDotExist;       // 是否包含小数点
    bool hasOperator;
};

#endif // MAINWINDOW_H
