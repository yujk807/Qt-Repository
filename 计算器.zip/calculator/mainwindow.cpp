#include "mainwindow.h"
#include "ui_mainwindow.h"



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

        firstNum = 0.0;
        secondNum = 0.0;
        operatorStr = "";
        isFirstInput = true;
        isDotExist = false;
        hasOperator = false;
        ui->displayEdit->setText("0");  // 显示框初始值


        connect(ui->btn0, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn1, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn2, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn3, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn4, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn5, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn6, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn7, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn8, &QPushButton::clicked, this, &MainWindow::onNumberClicked);
        connect(ui->btn9, &QPushButton::clicked, this, &MainWindow::onNumberClicked);


        connect(ui->btndot, &QPushButton::clicked, this, &MainWindow::onDotClicked);

        connect(ui->btnback, &QPushButton::clicked, this, &MainWindow::onBackspaceClicked);


        connect(ui->btnadd, &QPushButton::clicked, this, &MainWindow::onOperatorClicked);
        connect(ui->btnsub, &QPushButton::clicked, this, &MainWindow::onOperatorClicked);
        connect(ui->btnmul, &QPushButton::clicked, this, &MainWindow::onOperatorClicked);
        connect(ui->btndiv, &QPushButton::clicked, this, &MainWindow::onOperatorClicked);


        connect(ui->btnequal, &QPushButton::clicked, this, &MainWindow::onEqualClicked);

        connect(ui->btnclear, &QPushButton::clicked, this, &MainWindow::onClearClicked);


        connect(ui->btnpercent, &QPushButton::clicked, this, &MainWindow::onPercentClicked);


        this->setStyleSheet("background-color:#F5F5F5;");


        ui->displayEdit->setStyleSheet(R"(
            QLineEdit {
                background-color: white;
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 15px;
                font-size: 24pt;
                color: #333333;
                margin-bottom: 10px;
            }
        )");


        QList<QPushButton*> numBtns = {ui->btn0, ui->btn1, ui->btn2, ui->btn3, ui->btn4,
                                       ui->btn5, ui->btn6, ui->btn7, ui->btn8, ui->btn9, ui->btndot};
        for (QPushButton *btn : numBtns) {
            btn->setStyleSheet(R"(
                QPushButton {
                    background-color: white;
                    border: none;
                    border-radius: 25px;  // 圆形按钮
                    font-size: 18pt;
                    color: #333333;
                    height: 60px;
                    width: 60px;
                }
                QPushButton:hover {
                    background-color: #E0E0E0;  //  hover效果
                }
            )");
        }


        QList<QPushButton*> funcBtns = {ui->btnclear, ui->btnback, ui->btnpercent};
        for (QPushButton *btn : funcBtns) {
            btn->setStyleSheet(R"(
                QPushButton {
                    background-color: #E5E5E5;
                    border: none;
                    border-radius: 25px;
                    font-size: 18pt;
                    color: #333333;
                    height: 60px;
                    width: 60px;
                }
                QPushButton:hover {
                    background-color: #D0D0D0;
                }
            )");
        }


        QList<QPushButton*> opBtns = {ui->btnadd, ui->btnsub, ui->btnmul, ui->btndiv, ui->btnequal};
        for (QPushButton *btn : opBtns) {
            btn->setStyleSheet(R"(
                QPushButton {
                    background-color: #FF9500;
                    border: none;
                    border-radius: 25px;
                    font-size: 18pt;
                    color: white;
                    height: 60px;
                    width: 60px;
                }
                QPushButton:hover {
                    background-color: #FFB74D;
                }
            )");
        }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onNumberClicked()
{
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    QString numText = btn->text();
    QString displayText = ui->displayEdit->text();

    if (isFirstInput) {

        if (displayText == "0") {
            ui->displayEdit->setText(numText);
        } else {
            ui->displayEdit->setText(displayText + numText);
        }
    } else {

        if (hasOperator) {

            ui->displayEdit->setText(numText);
            hasOperator = false;

        } else {

            ui->displayEdit->setText(displayText + numText);
        }
    }
}


void MainWindow::onDotClicked()
{
    if (!isDotExist) {
        QString displayText = ui->displayEdit->text();
        ui->displayEdit->setText(displayText + ".");
        isDotExist = true;
    }
}


void MainWindow::onBackspaceClicked()
{
    QString displayText = ui->displayEdit->text();
    if (displayText.length() > 1) {
        displayText.chop(1);
        ui->displayEdit->setText(displayText);

        if (displayText.right(1) != ".") {
            isDotExist = false;
        }
    } else {

        ui->displayEdit->setText("0");
        isFirstInput = true;
        isDotExist = false;
    }
}


void MainWindow::onOperatorClicked()
{
    if (!hasOperator) {
       QPushButton *btn = qobject_cast<QPushButton*>(sender());
       operatorStr = btn->text();
       firstNum = ui->displayEdit->text().toDouble();


       ui->displayEdit->setText(ui->displayEdit->text() + operatorStr);


       hasOperator = true;
       isFirstInput = false;
       isDotExist = false;
   }
}


void MainWindow::onEqualClicked()
{
    double result = 0.0;

    secondNum = ui->displayEdit->text().toDouble();


    if (operatorStr == "+") {
        result = firstNum + secondNum;
    } else if (operatorStr == "-") {
        result = firstNum - secondNum;
    } else if (operatorStr == "*") {
        result = firstNum * secondNum;
    } else if (operatorStr == "/") {
        if (secondNum == 0) {
            ui->displayEdit->setText("Error");

            isFirstInput = true;
            isDotExist = false;
            hasOperator = false;
            operatorStr = "";
            return;
        }
        result = firstNum / secondNum;
    }


    int resultInt = static_cast<int>(result);
    if (result == resultInt) {
        ui->displayEdit->setText(QString::number(resultInt));
    } else {
        QString resultStr = QString::number(result, 'f', 6);
        QRegularExpression rx("\\.?0*$");
        resultStr.remove(rx);
        ui->displayEdit->setText(resultStr);
    }


    isFirstInput = true;
    isDotExist = false;
    hasOperator = false;
    operatorStr = "";
    firstNum = result;
}


void MainWindow::onClearClicked()
{
    ui->displayEdit->setText("0");
    firstNum = 0.0;
    secondNum = 0.0;
    operatorStr = "";
    isFirstInput = true;
    isDotExist = false;
    hasOperator = false;  // 清除运算符标记
}

void MainWindow::onPercentClicked()
{
    double num = ui->displayEdit->text().toDouble();
    double result = num / 100;


    int resultInt = static_cast<int>(result);
    if (result == resultInt) {

        ui->displayEdit->setText(QString::number(resultInt));
    } else {

        QString resultStr = QString::number(result, 'f', 6);
        QRegularExpression rx("\\.?0*$");
        resultStr.remove(rx);
        ui->displayEdit->setText(resultStr);
    }


    if (isFirstInput) {
        firstNum = result;
    } else {
        secondNum = result;
    }
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
        // 数字键（0-9）
        case Qt::Key_0: ui->btn0->click(); break;
        case Qt::Key_1: ui->btn1->click(); break;
        case Qt::Key_2: ui->btn2->click(); break;
        case Qt::Key_3: ui->btn3->click(); break;
        case Qt::Key_4: ui->btn4->click(); break;
        case Qt::Key_5: ui->btn5->click(); break;
        case Qt::Key_6: ui->btn6->click(); break;
        case Qt::Key_7: ui->btn7->click(); break;
        case Qt::Key_8: ui->btn8->click(); break;
        case Qt::Key_9: ui->btn9->click(); break;


        case Qt::Key_Plus: ui->btnadd->click(); break;    // +键
        case Qt::Key_Minus: ui->btnsub->click(); break;   // -键
        case Qt::Key_Asterisk: ui->btnmul->click(); break;// *键（小键盘）
        case Qt::Key_Slash: ui->btndiv->click(); break;   // /键


        case Qt::Key_Enter:
        case Qt::Key_Return:
            ui->btnequal->click(); break;
        case Qt::Key_Backspace: ui->btnback->click(); break;
        case Qt::Key_Delete: ui->btnclear->click(); break;
        case Qt::Key_Period: ui->btndot->click(); break;
        case Qt::Key_Percent: ui->btnpercent->click(); break;


        default: QMainWindow::keyPressEvent(event);
    }
}
