#include "TextEditorWindow.h"

TextEditorWindow::TextEditorWindow(QWidget *parent)
    : QMainWindow(parent),
    currentFilepath(""),
    isFileModified(false)
{
    // 初始化文本编辑区
    textEditArea = new QTextEdit(this);
    setCentralWidget(textEditArea);
    textEditArea->setLineWrapMode(QTextEdit::NoWrap);
    textEditArea->setPlaceholderText("请在此输入或粘贴文本...");
    textEditArea->setFont(QFont("Microsoft YaHei", 10));

    // 信号绑定：文本变化与光标移动
    connect(textEditArea, &QTextEdit::textChanged, this, &TextEditorWindow::updateFileModificationStatus);
    connect(textEditArea, &QTextEdit::cursorPositionChanged, this, &TextEditorWindow::refreshStatusBarInfo);
    connect(textEditArea, &QTextEdit::selectionChanged, this, &TextEditorWindow::adjustEditActionStates);

    // 初始化Action
    // 文件操作Action
    actNew = new QAction("新建(&N)", this);
    actNew->setShortcut(QKeySequence::New);
    actNew->setStatusTip("创建空白文本文件");
    actNew->setIcon(QIcon::fromTheme("document-new"));

    actOpen = new QAction("打开(&O)", this);
    actOpen->setShortcut(QKeySequence::Open);
    actOpen->setStatusTip("打开已存在的文本文件");
    actOpen->setIcon(QIcon::fromTheme("document-open"));

    actSave = new QAction("保存(&S)", this);
    actSave->setShortcut(QKeySequence::Save);
    actSave->setStatusTip("保存当前文本到文件");
    actSave->setIcon(QIcon::fromTheme("document-save"));

    actSaveAs = new QAction("另存为(&A)", this);
    actSaveAs->setStatusTip("将当前文本保存为新文件");
    actSaveAs->setIcon(QIcon::fromTheme("document-save-as"));

    actExit = new QAction("退出(&X)", this);
    actExit->setStatusTip("关闭文本编辑器");
    actExit->setIcon(QIcon::fromTheme("application-exit"));

    // 编辑操作Action
    actUndo = new QAction("撤销(&U)", this);
    actUndo->setShortcut(QKeySequence::Undo);
    actUndo->setStatusTip("撤销上一步操作");
    actUndo->setEnabled(false);
    actUndo->setIcon(QIcon::fromTheme("edit-undo"));

    actRedo = new QAction("重做(&R)", this);
    actRedo->setShortcut(QKeySequence::Redo);
    actRedo->setStatusTip("恢复上一步撤销的操作");
    actRedo->setEnabled(false);
    actRedo->setIcon(QIcon::fromTheme("edit-redo"));

    actCut = new QAction("剪切(&T)", this);
    actCut->setShortcut(QKeySequence::Cut);
    actCut->setStatusTip("剪切选中的文本到剪贴板");
    actCut->setEnabled(false);
    actCut->setIcon(QIcon::fromTheme("edit-cut"));

    actCopy = new QAction("复制(&C)", this);
    actCopy->setShortcut(QKeySequence::Copy);
    actCopy->setStatusTip("复制选中的文本到剪贴板");
    actCopy->setEnabled(false);
    actCopy->setIcon(QIcon::fromTheme("edit-copy"));

    actPaste = new QAction("粘贴(&P)", this);
    actPaste->setShortcut(QKeySequence::Paste);
    actPaste->setStatusTip("粘贴剪贴板中的文本");
    actPaste->setIcon(QIcon::fromTheme("edit-paste"));

    actFind = new QAction("查找(&F)", this);
    actFind->setShortcut(QKeySequence::Find);
    actFind->setStatusTip("查找指定文本内容");
    actFind->setIcon(QIcon::fromTheme("edit-find"));

    actReplace = new QAction("替换(&H)", this);
    actReplace->setShortcut(QKeySequence("Ctrl+H"));
    actReplace->setStatusTip("替换指定文本内容");
    actReplace->setIcon(QIcon::fromTheme("edit-replace"));

    actSelectAll = new QAction("全选(&A)", this);
    actSelectAll->setShortcut(QKeySequence::SelectAll);
    actSelectAll->setStatusTip("选中所有文本内容");

    // 格式操作Action
    actWordWrap = new QAction("自动换行(&W)", this);
    actWordWrap->setShortcut(QKeySequence("Ctrl+L"));
    actWordWrap->setStatusTip("开启/关闭文本自动换行");
    actWordWrap->setCheckable(true);
    actWordWrap->setIcon(QIcon::fromTheme("format-line-wrap"));

    actCustomFont = new QAction("自定义字体(&F)", this);
    actCustomFont->setStatusTip("设置文本字体、大小和样式");
    actCustomFont->setIcon(QIcon::fromTheme("format-font"));

    actFontColor = new QAction("字体颜色(&C)", this);
    actFontColor->setStatusTip("设置文本颜色");
    actFontColor->setIcon(QIcon::fromTheme("format-text-color"));

    actTextBgColor = new QAction("文本背景色(&B)", this);
    actTextBgColor->setStatusTip("设置选中文本的背景色");
    actTextBgColor->setIcon(QIcon::fromTheme("format-text-highlight"));

    actEditorBgColor = new QAction("编辑器背景(&E)", this);
    actEditorBgColor->setStatusTip("设置编辑器整体背景色");
    actEditorBgColor->setIcon(QIcon::fromTheme("format-background-color"));

    // 查看操作Action
    actShowToolBar = new QAction("显示工具栏(&T)", this);
    actShowToolBar->setStatusTip("显示或隐藏工具栏");
    actShowToolBar->setCheckable(true);
    actShowToolBar->setChecked(true);

    actShowStatusBar = new QAction("显示状态栏(&S)", this);
    actShowStatusBar->setStatusTip("显示或隐藏状态栏");
    actShowStatusBar->setCheckable(true);
    actShowStatusBar->setChecked(true);

    // 帮助操作Action
    actAbout = new QAction("关于(&A)", this);
    actAbout->setStatusTip("查看编辑器相关信息");
    actAbout->setIcon(QIcon::fromTheme("help-about"));

    // 初始化菜单栏
    QMenuBar *menuBar = new QMenuBar(this);
    setMenuBar(menuBar);

    QMenu *fileMenu = menuBar->addMenu("文件(&F)");
    fileMenu->addAction(actNew);
    fileMenu->addAction(actOpen);
    fileMenu->addAction(actSave);
    fileMenu->addAction(actSaveAs);
    fileMenu->addSeparator();
    fileMenu->addAction(actExit);

    QMenu *editMenu = menuBar->addMenu("编辑(&E)");
    editMenu->addAction(actUndo);
    editMenu->addAction(actRedo);
    editMenu->addSeparator();
    editMenu->addAction(actCut);
    editMenu->addAction(actCopy);
    editMenu->addAction(actPaste);
    editMenu->addSeparator();
    editMenu->addAction(actFind);
    editMenu->addAction(actReplace);
    editMenu->addSeparator();
    editMenu->addAction(actSelectAll);

    QMenu *formatMenu = menuBar->addMenu("格式(&O)");
    formatMenu->addAction(actWordWrap);
    formatMenu->addAction(actCustomFont);
    formatMenu->addAction(actFontColor);
    formatMenu->addAction(actTextBgColor);
    formatMenu->addAction(actEditorBgColor);

    QMenu *viewMenu = menuBar->addMenu("查看(&V)");
    viewMenu->addAction(actShowToolBar);
    viewMenu->addAction(actShowStatusBar);

    QMenu *helpMenu = menuBar->addMenu("帮助(&H)");
    helpMenu->addAction(actAbout);

    // 初始化工具栏
    fileToolBar = addToolBar("文件工具");
    fileToolBar->addAction(actNew);
    fileToolBar->addAction(actOpen);
    fileToolBar->addAction(actSave);
    fileToolBar->addAction(actSaveAs);
    fileToolBar->addSeparator();
    fileToolBar->addAction(actExit);

    editToolBar = addToolBar("编辑工具");
    editToolBar->addAction(actUndo);
    editToolBar->addAction(actRedo);
    editToolBar->addSeparator();
    editToolBar->addAction(actCut);
    editToolBar->addAction(actCopy);
    editToolBar->addAction(actPaste);
    editToolBar->addSeparator();
    editToolBar->addAction(actFind);
    editToolBar->addAction(actReplace);

    formatToolBar = addToolBar("格式工具");
    formatToolBar->addAction(actWordWrap);
    formatToolBar->addAction(actCustomFont);
    formatToolBar->addAction(actFontColor);
    formatToolBar->addAction(actEditorBgColor);

    // 初始化状态栏
    QStatusBar *statusBar = new QStatusBar(this);
    setStatusBar(statusBar);
    refreshStatusBarInfo();

    // 初始化对话框
    initFindDialog();
    initReplaceDialog();
    initAboutDialog();

    // 绑定Action与槽函数
    // 文件操作
    connect(actNew, &QAction::triggered, this, &TextEditorWindow::newFile);
    connect(actOpen, &QAction::triggered, this, &TextEditorWindow::openExistingFile);
    connect(actSave, &QAction::triggered, this, &TextEditorWindow::saveCurrentFile);
    connect(actSaveAs, &QAction::triggered, this, &TextEditorWindow::saveFileAs);
    connect(actExit, &QAction::triggered, this, &TextEditorWindow::exitEditor);

    // 编辑操作
    connect(actUndo, &QAction::triggered, textEditArea, &QTextEdit::undo);
    connect(actRedo, &QAction::triggered, textEditArea, &QTextEdit::redo);
    connect(actCut, &QAction::triggered, textEditArea, &QTextEdit::cut);
    connect(actCopy, &QAction::triggered, textEditArea, &QTextEdit::copy);
    connect(actPaste, &QAction::triggered, textEditArea, &QTextEdit::paste);
    connect(actFind, &QAction::triggered, this, &TextEditorWindow::showFindDialog);
    connect(actReplace, &QAction::triggered, this, &TextEditorWindow::showReplaceDialog);
    connect(actSelectAll, &QAction::triggered, textEditArea, &QTextEdit::selectAll);

    // 格式操作
    connect(actWordWrap, &QAction::triggered, this, &TextEditorWindow::toggleWordWrap);
    connect(actCustomFont, &QAction::triggered, this, &TextEditorWindow::customizeFont);
    connect(actFontColor, &QAction::triggered, this, &TextEditorWindow::changeFontColor);
    connect(actTextBgColor, &QAction::triggered, this, &TextEditorWindow::changeTextBgColor);
    connect(actEditorBgColor, &QAction::triggered, this, &TextEditorWindow::changeEditorBgColor);

    // 查看操作
    connect(actShowToolBar, &QAction::triggered, this, &TextEditorWindow::toggleToolBarVisibility);
    connect(actShowStatusBar, &QAction::triggered, this, &TextEditorWindow::toggleStatusBarVisibility);

    // 帮助操作
    connect(actAbout, &QAction::triggered, this, &TextEditorWindow::showAboutInfo);

    // 撤销/重做使能控制
    connect(textEditArea, &QTextEdit::undoAvailable, actUndo, &QAction::setEnabled);
    connect(textEditArea, &QTextEdit::redoAvailable, actRedo, &QAction::setEnabled);

    // 窗口初始设置
    setWindowTitle("未命名文档 - 简易文本编辑器");
    setWindowIcon(QIcon::fromTheme("accessories-text-editor"));
    resize(900, 600);
}

// 对话框初始化函数
void TextEditorWindow::initFindDialog()
{
    findDlg = new QDialog(this);
    findDlg->setWindowTitle("查找文本");
    findDlg->setFixedSize(400, 180);
    findDlg->setWindowIcon(QIcon::fromTheme("edit-find"));

    QVBoxLayout *mainLayout = new QVBoxLayout(findDlg);
    mainLayout->setSpacing(15);
    mainLayout->setContentsMargins(20, 20, 20, 15);

    // 查找输入区域
    QHBoxLayout *inputLayout = new QHBoxLayout();
    QLabel *findLabel = new QLabel("查找内容：", findDlg);
    findInput = new QLineEdit(findDlg);
    findInput->setPlaceholderText("请输入要查找的文本");
    inputLayout->addWidget(findLabel);
    inputLayout->addWidget(findInput);
    mainLayout->addLayout(inputLayout);

    // 查找选项区域
    QHBoxLayout *optionLayout = new QHBoxLayout();
    radioUp = new QRadioButton("向上查找", findDlg);
    radioDown = new QRadioButton("向下查找", findDlg);
    checkCaseSensitive = new QCheckBox("区分大小写", findDlg);
    radioDown->setChecked(true);
    optionLayout->addWidget(radioUp);
    optionLayout->addWidget(radioDown);
    optionLayout->addWidget(checkCaseSensitive);
    mainLayout->addLayout(optionLayout);

    // 按钮区域
    QHBoxLayout *btnLayout = new QHBoxLayout();
    btnFind = new QPushButton("查找下一个", findDlg);
    btnFindClose = new QPushButton("取消", findDlg);
    btnLayout->addWidget(btnFind);
    btnLayout->addWidget(btnFindClose);
    mainLayout->addLayout(btnLayout);

    // 信号绑定
    connect(btnFind, &QPushButton::clicked, this, &TextEditorWindow::performFind);
    connect(btnFindClose, &QPushButton::clicked, findDlg, &QDialog::close);
    connect(findInput, &QLineEdit::returnPressed, this, &TextEditorWindow::performFind);
}

void TextEditorWindow::initReplaceDialog()
{
    replaceDlg = new QDialog(this);
    replaceDlg->setWindowTitle("替换文本");
    replaceDlg->setFixedSize(450, 220);
    replaceDlg->setWindowIcon(QIcon::fromTheme("edit-replace"));

    QVBoxLayout *mainLayout = new QVBoxLayout(replaceDlg);
    mainLayout->setSpacing(12);
    mainLayout->setContentsMargins(20, 20, 20, 15);

    // 查找输入
    QHBoxLayout *findLayout = new QHBoxLayout();
    QLabel *findLabel = new QLabel("查找内容：", replaceDlg);
    findInput = new QLineEdit(replaceDlg);
    findInput->setPlaceholderText("请输入要查找的文本");
    findLayout->addWidget(findLabel);
    findLayout->addWidget(findInput);
    mainLayout->addLayout(findLayout);

    // 替换输入
    QHBoxLayout *replaceLayout = new QHBoxLayout();
    QLabel *replaceLabel = new QLabel("替换为：", replaceDlg);
    replaceInput = new QLineEdit(replaceDlg);
    replaceInput->setPlaceholderText("请输入替换后的文本");
    replaceLayout->addWidget(replaceLabel);
    replaceLayout->addWidget(replaceInput);
    mainLayout->addLayout(replaceLayout);

    // 选项区域
    QHBoxLayout *optionLayout = new QHBoxLayout();
    radioUp = new QRadioButton("向上查找", replaceDlg);
    radioDown = new QRadioButton("向下查找", replaceDlg);
    checkCaseSensitive = new QCheckBox("区分大小写", replaceDlg);
    radioDown->setChecked(true);
    optionLayout->addWidget(radioUp);
    optionLayout->addWidget(radioDown);
    optionLayout->addWidget(checkCaseSensitive);
    mainLayout->addLayout(optionLayout);

    // 按钮区域
    QHBoxLayout *btnLayout = new QHBoxLayout();
    btnFind = new QPushButton("查找下一个", replaceDlg);
    btnReplace = new QPushButton("替换", replaceDlg);
    btnReplaceAll = new QPushButton("全部替换", replaceDlg);
    btnReplaceClose = new QPushButton("取消", replaceDlg);
    btnLayout->addWidget(btnFind);
    btnLayout->addWidget(btnReplace);
    btnLayout->addWidget(btnReplaceAll);
    btnLayout->addWidget(btnReplaceClose);
    mainLayout->addLayout(btnLayout);

    // 信号绑定
    connect(btnFind, &QPushButton::clicked, this, &TextEditorWindow::performFind);
    connect(btnReplace, &QPushButton::clicked, this, &TextEditorWindow::performReplace);
    connect(btnReplaceAll, &QPushButton::clicked, this, [=]() {
        QString findStr = findInput->text();
        QString replaceStr = replaceInput->text();
        if (findStr.isEmpty()) {
            QMessageBox::warning(this, "提示", "请输入要查找的文本内容！");
            return;
        }

        QTextDocument::FindFlags flags;
        if (checkCaseSensitive->isChecked()) {
            flags |= QTextDocument::FindCaseSensitively;
        }

        int replaceCount = 0;
        textEditArea->moveCursor(QTextCursor::Start);
        while (textEditArea->find(findStr, flags)) {
            textEditArea->textCursor().insertText(replaceStr);
            replaceCount++;
        }

        QMessageBox::information(this, "替换完成", QString("共成功替换 %1 处匹配内容").arg(replaceCount));
    });
    connect(btnReplaceClose, &QPushButton::clicked, replaceDlg, &QDialog::close);
    connect(findInput, &QLineEdit::returnPressed, this, &TextEditorWindow::performFind);
}

void TextEditorWindow::initAboutDialog()
{
    aboutDlg = new QDialog(this);
    aboutDlg->setWindowTitle("关于简易文本编辑器");
    aboutDlg->setFixedSize(380, 250);
    aboutDlg->setWindowIcon(QIcon::fromTheme("help-about"));

    QVBoxLayout *mainLayout = new QVBoxLayout(aboutDlg);
    mainLayout->setSpacing(20);
    mainLayout->setContentsMargins(20, 20, 20, 20);

    QLabel *iconLabel = new QLabel(aboutDlg);
    iconLabel->setPixmap(QIcon::fromTheme("accessories-text-editor").pixmap(QSize(64, 64)));
    iconLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(iconLabel);

    QLabel *infoLabel = new QLabel(aboutDlg);
    infoLabel->setText(QString("牙缝哥文本编辑器 V1.1\n\n"
                               "开发者：牙缝哥\n"
                               "学号：2023414300120\n"
                               "更新时间：%1\n"
                               "基于 Qt 5.12.11 开发").arg(QDate::currentDate().toString("yyyy-MM-dd")));
    infoLabel->setAlignment(Qt::AlignCenter);
    infoLabel->setFont(QFont("Microsoft YaHei", 10));
    mainLayout->addWidget(infoLabel);

    QPushButton *okBtn = new QPushButton("确定", aboutDlg);
    okBtn->setFixedSize(80, 30);
    mainLayout->addWidget(okBtn, 0, Qt::AlignCenter);

    connect(okBtn, &QPushButton::clicked, aboutDlg, &QDialog::close);
}

// 文件操作函数
void TextEditorWindow::newFile()
{
    if (isFileModified) {
        QMessageBox::StandardButton ret = QMessageBox::question(this, "提示",
                                                                "当前文档已修改，是否保存？",
                                                                QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save) {
            saveCurrentFile();
        } else if (ret == QMessageBox::Cancel) {
            return;
        }
    }

    textEditArea->clear();
    currentFilepath = "";
    isFileModified = false;
    setWindowTitle("未命名文档 - 简易文本编辑器");
    lastSavedTime = QDateTime::currentDateTime();
}

void TextEditorWindow::openExistingFile()
{
    if (isFileModified) {
        QMessageBox::StandardButton ret = QMessageBox::question(this, "提示",
                                                                "当前文档已修改，是否保存？",
                                                                QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save) {
            saveCurrentFile();
        } else if (ret == QMessageBox::Cancel) {
            return;
        }
    }

    QString filePath = QFileDialog::getOpenFileName(this, "打开文件", "",
                                                    "文本文件 (*.txt);;所有文件 (*.*)");
    if (filePath.isEmpty()) {
        return;
    }

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "错误", "无法打开文件：" + file.errorString());
        return;
    }

    QTextStream in(&file);
    textEditArea->setPlainText(in.readAll());
    file.close();

    currentFilepath = filePath;
    isFileModified = false;
    lastSavedTime = QFileInfo(filePath).lastModified();
    QString fileName = QFileInfo(filePath).fileName();
    setWindowTitle(QString("%1 - 简易文本编辑器").arg(fileName));
}

void TextEditorWindow::saveCurrentFile()
{
    if (currentFilepath.isEmpty()) {
        saveFileAs();
        return;
    }

    QFile file(currentFilepath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "错误", "无法保存文件：" + file.errorString());
        return;
    }

    QTextStream out(&file);
    out << textEditArea->toPlainText();
    file.close();

    isFileModified = false;
    lastSavedTime = QDateTime::currentDateTime();
    QString fileName = QFileInfo(currentFilepath).fileName();
    setWindowTitle(QString("%1 - 简易文本编辑器").arg(fileName));
}

void TextEditorWindow::saveFileAs()
{
    QString filePath = QFileDialog::getSaveFileName(this, "另存为", "",
                                                    "文本文件 (*.txt);;所有文件 (*.*)");
    if (filePath.isEmpty()) {
        return;
    }

    if (!filePath.endsWith(".txt", Qt::CaseInsensitive)) {
        filePath += ".txt";
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "错误", "无法保存文件：" + file.errorString());
        return;
    }

    QTextStream out(&file);
    out << textEditArea->toPlainText();
    file.close();

    currentFilepath = filePath;
    isFileModified = false;
    lastSavedTime = QDateTime::currentDateTime();
    QString fileName = QFileInfo(filePath).fileName();
    setWindowTitle(QString("%1 - 简易文本编辑器").arg(fileName));
}

void TextEditorWindow::exitEditor()
{
    if (isFileModified) {
        QMessageBox::StandardButton ret = QMessageBox::question(this, "提示",
                                                                "当前文档已修改，是否保存？",
                                                                QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save) {
            saveCurrentFile();
        } else if (ret == QMessageBox::Cancel) {
            return;
        }
    }

    close();
}

// 编辑操作函数
void TextEditorWindow::undoLastAction()
{
    textEditArea->undo();
}

void TextEditorWindow::redoLastAction()
{
    textEditArea->redo();
}

void TextEditorWindow::cutSelectedText()
{
    textEditArea->cut();
}

void TextEditorWindow::copySelectedText()
{
    textEditArea->copy();
}

void TextEditorWindow::pasteText()
{
    textEditArea->paste();
}

void TextEditorWindow::showFindDialog()
{
    findDlg->show();
    findInput->clear();
    findInput->setFocus();
}

void TextEditorWindow::performFind()
{
    QString findStr = findInput->text();
    if (findStr.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入要查找的文本内容！");
        return;
    }

    QTextDocument::FindFlags flags;
    if (radioUp->isChecked()) {
        flags |= QTextDocument::FindBackward;
    }
    if (checkCaseSensitive->isChecked()) {
        flags |= QTextDocument::FindCaseSensitively;
    }

    bool found = textEditArea->find(findStr, flags);
    if (!found) {
        QMessageBox::information(this, "查找结果", "未找到指定文本：" + findStr);
        textEditArea->moveCursor(QTextCursor::Start);
    }
}

void TextEditorWindow::showReplaceDialog()
{
    replaceDlg->show();
    findInput->clear();
    replaceInput->clear();
    findInput->setFocus();
}

void TextEditorWindow::performReplace()
{
    QString findStr = findInput->text();
    QString replaceStr = replaceInput->text();
    if (findStr.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入要查找的文本内容！");
        return;
    }

    QTextCursor cursor = textEditArea->textCursor();
    if (cursor.selectedText() == findStr) {
        cursor.insertText(replaceStr);
        performFind();
    } else {
        bool found = textEditArea->find(findStr, radioUp->isChecked() ? QTextDocument::FindBackward : QTextDocument::FindFlags());
        if (!found) {
            QMessageBox::information(this, "替换结果", "未找到指定文本：" + findStr);
        }
    }
}

void TextEditorWindow::selectAllText()
{
    textEditArea->selectAll();
}

// 格式操作函数
void TextEditorWindow::toggleWordWrap()
{
    if (actWordWrap->isChecked()) {
        textEditArea->setLineWrapMode(QTextEdit::WidgetWidth);
    } else {
        textEditArea->setLineWrapMode(QTextEdit::NoWrap);
    }
}

void TextEditorWindow::customizeFont()
{
    bool ok;
    QFont selectedFont = QFontDialog::getFont(&ok, textEditArea->font(), this, "选择字体");
    if (ok) {
        textEditArea->setFont(selectedFont);
    }
}

void TextEditorWindow::changeFontColor()
{
    QColor color = QColorDialog::getColor(textEditArea->textColor(), this, "选择字体颜色");
    if (color.isValid()) {
        textEditArea->setTextColor(color);
    }
}

void TextEditorWindow::changeTextBgColor()
{
    QColor color = QColorDialog::getColor(textEditArea->textBackgroundColor(), this, "选择文本背景色");
    if (color.isValid()) {
        textEditArea->setTextBackgroundColor(color);
    }
}

void TextEditorWindow::changeEditorBgColor()
{
    QColor color = QColorDialog::getColor(textEditArea->palette().base().color(), this, "选择编辑器背景色");
    if (color.isValid()) {
        QPalette palette = textEditArea->palette();
        palette.setColor(QPalette::Base, color);
        textEditArea->setPalette(palette);
    }
}

// 查看操作函数
void TextEditorWindow::toggleToolBarVisibility()
{
    bool isVisible = actShowToolBar->isChecked();
    fileToolBar->setVisible(isVisible);
    editToolBar->setVisible(isVisible);
    formatToolBar->setVisible(isVisible);
}

void TextEditorWindow::toggleStatusBarVisibility()
{
    statusBar()->setVisible(actShowStatusBar->isChecked());
}

// 帮助操作函数
void TextEditorWindow::showAboutInfo()
{
    aboutDlg->show();
}

// 辅助函数
void TextEditorWindow::updateFileModificationStatus()
{
    if (!isFileModified) {
        isFileModified = true;
        QString currentTitle = windowTitle();
        if (!currentTitle.startsWith("*")) {
            setWindowTitle("*" + currentTitle);
        }
    }
    refreshStatusBarInfo();
}

void TextEditorWindow::refreshStatusBarInfo()
{
    QTextCursor cursor = textEditArea->textCursor();
    int lineNum = cursor.blockNumber() + 1;
    int colNum = cursor.columnNumber() + 1;
    int textLength = textEditArea->toPlainText().length();
    QString modifyStatus = isFileModified ? "（已修改）" : "（已保存）";
    QString lastSaveTime = lastSavedTime.toString("yyyy-MM-dd HH:mm");

    statusBar()->showMessage(QString("行：%1 列：%2 | 字符数：%3 | %4 | 最后保存：%5")
                                 .arg(lineNum).arg(colNum).arg(textLength).arg(modifyStatus).arg(lastSaveTime));
}

void TextEditorWindow::adjustEditActionStates()
{
    bool hasSelection = !textEditArea->textCursor().selectedText().isEmpty();
    actCut->setEnabled(hasSelection);
    actCopy->setEnabled(hasSelection);
}
