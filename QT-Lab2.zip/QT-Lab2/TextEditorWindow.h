#ifndef TEXTEDITORWINDOW_H
#define TEXTEDITORWINDOW_H

#include <QMainWindow>
#include <QTextEdit>
#include <QAction>
#include <QToolBar>
#include <QMenu>
#include <QStatusBar>
#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QRadioButton>
#include <QCheckBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFileDialog>
#include <QFontDialog>
#include <QColorDialog>
#include <QMessageBox>
#include <QTextCursor>
#include <QFileInfo>
#include <QDateTime>
#include <QMenuBar>

class TextEditorWindow : public QMainWindow
{
    Q_OBJECT

public:
    TextEditorWindow(QWidget *parent = nullptr);
    ~TextEditorWindow() = default;

private slots:
    // 文件操作
    void newFile();
    void openExistingFile();
    void saveCurrentFile();
    void saveFileAs();
    void exitEditor();

    // 编辑操作
    void undoLastAction();
    void redoLastAction();
    void cutSelectedText();
    void copySelectedText();
    void pasteText();
    void showFindDialog();
    void performFind();
    void showReplaceDialog();
    void performReplace();
    void selectAllText();

    // 格式操作
    void toggleWordWrap();
    void customizeFont();
    void changeFontColor();
    void changeTextBgColor();
    void changeEditorBgColor();

    // 查看操作
    void toggleToolBarVisibility();
    void toggleStatusBarVisibility();

    // 帮助操作
    void showAboutInfo();

    // 辅助操作
    void updateFileModificationStatus();
    void refreshStatusBarInfo();
    void adjustEditActionStates();

private:
    // 核心组件
    QTextEdit *textEditArea;
    QAction *actNew, *actOpen, *actSave, *actSaveAs, *actExit;
    QAction *actUndo, *actRedo, *actCut, *actCopy, *actPaste, *actFind, *actReplace, *actSelectAll;
    QAction *actWordWrap, *actCustomFont, *actFontColor, *actTextBgColor, *actEditorBgColor;
    QAction *actShowToolBar, *actShowStatusBar, *actAbout;

    QToolBar *fileToolBar;
    QToolBar *editToolBar;
    QToolBar *formatToolBar;

    QString currentFilepath;
    bool isFileModified;
    QDateTime lastSavedTime;

    // 对话框相关
    void initFindDialog();
    void initReplaceDialog();
    void initAboutDialog();

    QDialog *findDlg;
    QLineEdit *findInput;
    QRadioButton *radioUp, *radioDown;
    QCheckBox *checkCaseSensitive;
    QPushButton *btnFind, *btnFindClose;

    QDialog *replaceDlg;
    QLineEdit *replaceInput;
    QPushButton *btnReplace, *btnReplaceAll, *btnReplaceClose;

    QDialog *aboutDlg;
};

#endif // TEXTEDITORWINDOW_H
